'use strict';

module.exports = document.createElement('div').style;

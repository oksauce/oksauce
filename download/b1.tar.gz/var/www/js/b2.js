
var searchCount = 50;
var searching = 0;
var lastGuest;


function searchFunction (stay){
	

	
	
	var t = document.getElementById("searchInput");
	
	
//	if (t.value.toLowerCase() == "usb") {
//		openUSBPanel ();
//		return;
//	}	
			
	if (t.value.toLowerCase() == "podcast") {
		openPodcastPanel ();
		return;
	}
	if (isBTube() && (t.value.toLowerCase() == "debug")) {
		openbTubeDebugPanel ();
		return;
	}

	if (searching){
		newSearch = 1;
		return;
	}
	else {
		searching = 1;
		newSearch = 0;
	}	
	
	var urlTail = 'search';
	searchOffset = 0;

	if (!searchArtists) urlTail += '&artists=N';
	if (!searchAlbums) urlTail += '&albums=N';
	if (!searchTracks) urlTail += '&tracks=N';
	urlTail += '&radio=N';	
	if (!searchVideos) urlTail += '&video=N';	

	if ((lastGuest==1)&&(lastGuestPlaylist!=0)) urlTail += '&playlist='+(lastGuestPlaylist-1);
		
	urlTail += '&offset='+searchOffset;
	urlTail += '&count='+searchCount;

	urlTail += '&time='+new Date ().getTime();			// IE
	
	urlTail += '&string='+t.value
	
	console.log ("searchFunction "+urlTail);
	
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		
//		console.log ("Got search results length = "+data.length);
		
		matches = data;
		var results = $('#Results');
		results.children().remove();
		var l = data.length;
		for (var i=0;i<l;i++) 
			results.append(makeSearchResult (i,data[i]));

		box = $('#SearchContainer');
		if (!stay) box.scrollTop(0);	

		
			
	}).always (function (){
		
		searching = 0;
		if (newSearch){
			newSearch = 0;
			searchFunction ();
		}

	});	
}	


function searchMore (){

//	alert ("searchMore ()");
	
	if (searching) return;

	if (!$('#SearchContainer').is(":visible")) return;
	
	if (!$('#Results').children ().length) {
		$('#SearchContainer').scrollTop(0);		
		return;	
	}
	
	var t = document.getElementById("searchInput");
	var urlTail = 'search';
	searchOffset += searchCount;
	
	if (!searchArtists) urlTail += '&artists=N';
	if (!searchAlbums) urlTail += '&albums=N';
	if (!searchTracks) urlTail += '&tracks=N';
	urlTail += '&radio=N';	
	if (!searchVideos) urlTail += '&video=N';	

	if ((lastGuest==1)&&(lastGuestPlaylist!=0)) urlTail += '&playlist='+(lastGuestPlaylist-1);
	
	urlTail += '&offset='+searchOffset;
	urlTail += '&count='+searchCount;

	urlTail += '&time='+new Date ().getTime();			// IE
	
	urlTail += '&string='+t.value
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		
		if (data.length){
			var results = $('#Results');
			var l = data.length;
			for (var i=0;i<l;i++) {
				results.append(makeSearchResult (matches.length,data[i]));
				matches.push(data[i]);
			}
		}
		else {
			searchOffset -= searchCount;
		}	
			
	});	
	
	

}

	

function makeSearchResult (i,n){
	
	var menu;
	var t;
	var id = n.id;
	var name = '';
	var ariaName = '';
	
	if (isTrack(id)||isUSBTrack(id)) {
		name = n.track;
		ariaName = 'Track: '+name;
	}	
	else if (isAlbum(id)||isUSBAlbum(id)) {
//		name = stripClass(n.album);
		name = n.album;
		ariaName = 'Album: '+name;
	}	
	else if (isArtist(id)||isUSBArtist(id)) {
		name = n.artist;
		ariaName = 'Artist: '+name;		
	}	
	else if (isRadio(id)) {
		name = n.radio;
		ariaName = 'Radio: '+name;		
	}	
	else if (isVideo(id)) {
		name = n.video;
		ariaName = 'Video: '+name;		
	}

/*	
	if (searchResultsHaveFocus) t = 'tabindex="0"';
	else t = 'tabindex="-1"';
*/
	t = "";
	
	if (isRadio(id)||isUSBTrack(id)||isUSBAlbum(id)||isUSBArtist(id)) menu = '<div class="flex1"></div>';
	else menu = '<div class="flex1 center"><span class="soft iconEllipsisH" onclick="searchItemFunction('+i+')"</span></div>';
	
	return $('<div '+t+' class="darkRow w3-row mylink"><div class="flex1 center"><span class="flex1 soft iconPlay" onclick="playTestFunction('+i
				+')"</span></div><div class="flex6" onclick="searchItemClick('+i+')">'+getIcon(id)+' '+name
				+'</div>'+
				menu+
				'</div>');
};



function playTestFunction (index){
	var id = matches[index].id
//	alert ("playTestFunction "+id);
	command = 'playID&'+id
	$.get('b2cgi.fcgi',command,function(data){});
	activateNowPlayingTab ();		
}	



function isTrack (id){
	return ((id >= 2000000)&&(id < 3000000));
}

function isAlbum (id){	
	return ((id >= 1000000)&&(id < 2000000));
}

function isArtist (id){	
	return ((id >= 3000000)&&(id < 4000000));
}

function isPlaylist (id){	
	return ((id >= 4000000)&&(id < 5000000));
}

function isRadio (id){	
	return ((id >= 5000000)&&(id < 6000000));
}

function isVideo (id){	
	return ((id >= 8000000)&&(id < 9000000));
}

function isUSBAlbum (id){	
	return ((id >= 9000000)&&(id < 10000000));
}

function isUSBTrack (id){	
	return ((id >= 10000000)&&(id < 11000000));
}

function isUSBArtist (id){	
	return ((id >= 11000000)&&(id < 12000000));
}

function isPlaylistIndex (id){
	return (id < 1000000);
}

function playlistToID (index){
	return 4000000+index;
}	

function trackIcon () {return '<span class="iconMusic"></span>'};
function artistIcon () {return '<span class="iconUser"></span>'};
function albumIcon () {return '<span class="iconCD"></span>'};

function USBTrackIcon () {return '<span class="iconMusic usbIcon"></span>'};
function USBArtistIcon () {return '<span class="iconUser usbIcon"></span>'};
function USBAlbumIcon () {return '<span class="iconCD usbIcon"></span>'};



function getIcon (id){
	if (isTrack(id)) return trackIcon();
	if (isArtist(id)) return artistIcon();
	if (isPlaylist(id)) return '<span class="iconList"></span>';
	if (isAlbum(id)) return albumIcon();
	if (isRadio(id)) return ' <span class="iconRadio"></span> ';
	if (isVideo(id)) return ' <span class="iconYoutube youtubeIcon"> </span> ';
	if (isUSBTrack(id)) return USBTrackIcon();
	if (isUSBArtist(id)) return USBArtistIcon();
	if (isUSBAlbum(id)) return USBAlbumIcon();
	return '<span class="iconExclamation"></span>';		
}	


function displayCurrentArtBlob (){
	

	console.log ("displayCurrentArtBlob ()");
	var art = $('#nowPlayingArt');

			
	var xhr = new XMLHttpRequest ();
	xhr.open ("GET","b2gci.fcgi?getCurrentArt&time="+ new Date ().getTime());
	xhr.responseType = "blob";

	xhr.onload = function (){

		var	imageUrl;
			
		console.log ("displayCurrentArtBlob displayCurrentArt size="+	this.response.size);
			
//		if (this.response.size != lastNowPlayingArtSize){

			lastNowPlayingArtSize = this.response.size;

			if (this.response.size){
				var urlCreator = window.URL || window.webkitURL;
				imageUrl = urlCreator.createObjectURL (this.response);
			}
			else imageUrl = "noimage.jpg";	
			
			art.children().remove();
			art.append ('<img src="'+imageUrl+'" width="100%">');
		
//		}
 
	};
	xhr.send ();
	
}


function displayCurrentArt (){
	
	console.log ("displayCurrentArt ()");
	var art = $('#nowPlayingArt');

	var urlTail = "getCurrentArtPath&time="+ new Date ().getTime();
	$.getJSON('b2gci.fcgi',urlTail,function(data){


		console.log ("displayCurrentArt got "+data);

		if (data) {
			if (data == "tag") displayCurrentArtBlob ();
			else {
				art.children().remove();
				art.append ('<img src="'+data+'" width="100%">');
				lastNowPlayingArtSize =	0;			
			}					
		}			
		else {
			art.children().remove();
			art.append ('<img src="noimage.jpg" width="100%">');
			lastNowPlayingArtSize =	0;	
		}	
		
	});	
}


function displayArt (id){
	
	var xhr = new XMLHttpRequest ();
	xhr.open ("GET","b2gci.fcgi?getAlbumArt&id="+id+"&time="+ new Date ().getTime());
	xhr.responseType = "blob";
	xhr.onload = function (){
	
		var	imageUrl;
			
		if (this.response.size){
			var urlCreator = window.URL || window.webkitURL;
			imageUrl = urlCreator.createObjectURL (this.response);
		}
		else imageUrl = "noimage.jpg";
		
		img = $("#albumImage");
		img.attr ("src",imageUrl);

	};	
	xhr.send ();	
	
}



function makeAlbumItem (i){
	
	var menu;
	
	if (isUSBTrack(albumTracks[i].id))
		menu = '<div class="flex1 center"></div>';
	else 	
		menu = '<div class="flex1 center"><span class="iconEllipsisH" onclick="albumItemFunction('+i+')"</span></div>';

	var el = $('<div class="mylink darkRow">'+
					'<div class="flex1 center"><span onclick="playAlbumTrack('+i+')" class="iconPlay"></span></div>'+
					'<div class="flex6 onclick="albumItemFunction('+i+')">'+albumTracks[i].name+'</div>'+menu+'</div>');	
	return el;
	
}	

function listalbumAndArtistFunction (id){
	
	selectedAlbum = id;

	var urlTail = 'listalbum&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	

	$.getJSON('b2gci.fcgi',urlTail,function(data){
		albumTracks = data;
		var results = $('#AlbumTracks');
		results.children().remove();
		var l = data.length;
				
		for (var i=0;i<l;i++){
			results.append(makeAlbumItem(i));
		}
	});

	displayArt (id);	
	
	var urlTail = 'albumDetails&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		selectedAlbumName = data.name;
		$('#albumname').text(data.name);		
	});	
	
	urlTail = 'getParent&id='+id+" &"+new Date ().getTime();	// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){
//		console.log ("Reply ID = "+data.id);
		listArtistFunction (data.id);		
	});
}


function listalbumAndArtistInSitu(id){
	listalbumAndArtistFunction (id);
}	

function listParentArtist (id){

	console.log ("listParentArtist ("+id+")");
	
	urlTail = 'getParent&id='+id+" &"+new Date ().getTime();	// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){
//		console.log ("Reply ID = "+data.id);
		listArtistFunction (data.id);		
	});	
}


function listRandomAlbumAndArtistFunction (){

	var urlTail = 'getWebInfo&time='+ new Date ().getTime();		// IE;

	$.getJSON('b2gci.fcgi',urlTail,function(data){
		var id = Math.floor (Math.random()*data.albums) + 1000000;
		listalbumAndArtistFunction (id);		
	});	
}

function listArtistAndFirstAlbum (id,listAlbumFlag){
	
	var urlTail = 'listartist&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	

	$.getJSON('b2gci.fcgi',urlTail,function(data){
		artistAlbums = data;
		var results = $('#ArtistAlbums');
		results.children().remove();
		var l = data.length;

		for (var i=0;i<l;i++){

			if (isUSBAlbum(artistAlbums[i].id)){
				menu = '<div class="flex1"></div>';
			}
			else {
				menu = '<div class="flex1 center"><span class="iconEllipsisH" onclick="artistItemFunction('+i+')"></span></div>';
			}	

			results.append('<div class="darkRow mylink"><div class="flex1 center"><span class="iconPlay" onclick="playArtistAlbum('+i+')"></span></div>'+
								'<div class="flex2 middleItem"><img class="circle" id="aai'+i+'" width="100%"></div>'+
								'<div class="flex6 middleItem" onclick="artistAlbumClick('+i+')">'+data[i].name+"</div>"+menu+"</div>");
			
			putArtHere (artistAlbums[i].id,"#aai"+i);					
		}

		if (listAlbumFlag) listalbumFunction (artistAlbums[0].id);
		
		if (l == 1)	$("#albumCount").text ("1 album");
		else $("#albumCount").text (l+ " albums")
						
			
	});	


	var urlTail = 'artistDetails&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	

	$.getJSON('b2gci.fcgi',urlTail,function(data){
		selectedArtistName = data.name;
		$('#artistname').text(data.name);		
	});	
	
}

function listArtistFunction (id){

	listArtistAndFirstAlbum (id,false);
}


function putArtHere (id,locationId){
	
	console.log ("putArtHere "+id+" "+locationId);
	
	var xhr = new XMLHttpRequest ();
	xhr.open ("GET","b2gci.fcgi?getAlbumArt&id="+id+"&time="+ new Date ().getTime());
	xhr.responseType = "blob";
	xhr.onload = function (){	
		
		
		var	imageUrl;
			
		if (this.response.size){

			var urlCreator = window.URL || window.webkitURL;
			imageUrl = urlCreator.createObjectURL (this.response);
		}
		else imageUrl = "noimage.jpg";
		
		img = $(locationId);
		img.attr ("src",imageUrl);

	};	
	xhr.send ();	
	
}


function playArtistAlbum (index){

	id = artistAlbums[index].id;
	command = 'playID&'+id
	$.get('b2cgi.fcgi',command,function(data){});
	activateNowPlayingTab ();	

}

function listalbumFunction (id){
	
	selectedAlbum = id;
	var l;
	
	var urlTail = 'listalbum&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		albumTracks = data;
		var results = $('#AlbumTracks');
		results.children().remove();
		l = data.length;

		if (l == 1)	$("#trackCount").text ("1 track");
		else $("#trackCount").text (l+ " tracks")
				
		for (var i=0;i<l;i++){
//			var el = $('<tr class="mylink"><td><span onclick="playAlbumTrack('+i+')" class="glyphicon glyphicon-play"></span></td><td class="col-sm-11" draggable="true" ondragstart="dragAlbumTrack(event)" ondblclick="albumTrackRename('+i+')">'+data[i].name+"</td></tr>");
			results.append(makeAlbumItem(i));

		}
				
	});

	console.log ("albumDetails");
	
	displayArt (id);	
	
	var urlTail = 'albumDetails&id='+id;
	urlTail += '&time='+new Date ().getTime();			// IE	
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		selectedAlbumName = data.name;
		$('#albumname').text(data.name);		

	});		

}	

function listTrackFunction (id){
	var urlTail = 'getParent&id='+id+" &"+new Date ().getTime();	// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		console.log ("Reply ID = "+data.id);
		listalbumAndArtistFunction (data.id);		
	});
}


function artistAlbumClick (i){
	id = artistAlbums[i].id;
//	console.log ("artistAlbumClick "+ id);
	if (isAlbum(id)||isUSBAlbum(id)) listalbumFunction (id);
	activateAlbumTab ();	
}

function startFfmpeg (url,title,id){
	

	var urlTail = 'ffmpeg&id='+id+'&title='+title+'&url='+url;
	$.getJSON('b2gci.fcgi',urlTail,function(data){});
}

function startOmxplayer (url,title,id){
	

	var urlTail = 'omxplayer&id='+id+'&title='+title+'&url='+url;
	$.getJSON('b2gci.fcgi',urlTail,function(data){});
}


function myFilter (item){
	
//	console.log ("myFilter");
//	console.dir (item);
//	return (item.container=="mp4") && (item.quality=="medium");
	return (item.container=="mp4");
}	


function addToYoutubeHistory (title,url){

	var item = [title,url];
	var i;
	
	for (i=0;i<youtubeHistory.length;i++){
		if (youtubeHistory[i][0]===title)
			youtubeHistory.splice (i,1);
	}		
	
	youtubeHistory.unshift (item);
	while (youtubeHistory.length > 20) youtubeHistory.pop ();
}

function uploadHistory (){
	
	var formData = new FormData ();

	formData.append ("history",JSON.stringify(youtubeHistory));

	$.ajax ({
		url: 'b2cgi.fcgi?uploadYoutubeHistory',
		type: 'POST',
		data: formData,
		cache: false,
		dataType: 'json',
		processData: false,
		contentType: false,
		success: function (data, textStatus, jqXHR) {
			console.log ("uploadHistory OK");
		},
		error: function (jqXHR, textStatus, errorThrown){
			console.log ("uploadHistory Error "+errorThrown);	
		}	
	});	
}

function startYoutube (yturl,callback){
	
	console.log ("startYoutube ("+yturl+")");

	$("#youtubeStarting").show ();		

	var options;
	
	
	if (isBTube()) options = {filter: myFilter};
	else options = {filter: 'audioonly'};

	ytdl (yturl,options,function (err,url,info){

		
		if (err) {
			$('#youtubeStarting').hide ();
			console.log ("ytdl-core failed "+err);
			if (callback) callback ();
			else alert ("That didn't work try again");
		}	
		else {
			console.log ("ytdl-core returned "+url); 
			
			console.log ("nowPlaying.btube = "+nowPlaying.btube);
			
			if (nowPlaying.btube) startOmxplayer (url,info.title,info.video_id);			
			else startFfmpeg (url,info.title,info.video_id);

			$('#youtubeStarting').hide ();

			console.log ("Title ",info.title); 
			console.dir (info);
					
			addToYoutubeHistory (info.title,yturl);
			uploadHistory ();
			refreshHistoryList ();
		
		}	
	});		
	
}


function playYoutubeSearchResult(index){

	cloudLog (youtubeSearchResults[index][1]);
	startYoutube (youtubeSearchResults[index][1]);
	activateNowPlayingTab ();	

}


function makeYoutubeItem (text,url,onclick,index,showMenu){

		var img = "";
		if (!showMenu || !isBTube ()){
			var id = getVideoID (url);
			if (id) img = '<img width="100%" src = "https://i.ytimg.com/vi/'+id+'/default.jpg">';
		}	
		if (showMenu){
			var trash = '<div class="mylink flex1 center" onclick="youtubeItemMenu('+index+')"><span id="randomIcon" class="iconTrash" ></span></td>';
			var tdClass = '<div class="mylink flex8 middleItem" onclick="'+onclick+'('+index+')">';
		}
		else {
			var trash = '';
			var tdClass = '<div class="mylink flex9 middleItem" onclick="'+onclick+'('+index+')">';			
		}		
		
//		console.log ("img = "+img);
		
		return 	$('<div class="mylink darkRow"><div class="flex3 youtube" onclick="'+onclick+'('+index+')">'+img+
					'</div>'+
					tdClass+text+'</div>'+trash+'</div>');
	
}	

function refreshSearchResults (){
	var tb = $('#youtubeSearchResults');
	tb.children().remove();
	var l = youtubeSearchResults.length;
	for (var i=0;i<l;i++){ 

		tb.append (makeYoutubeItem(youtubeSearchResults[i][0],youtubeSearchResults[i][1],"playYoutubeSearchResult",i,false));
			
	}
	
}



function allIndexOf (str, toSearch){
	var indices = [];
	for (var pos = str.indexOf (toSearch); pos !== -1; pos = str.indexOf (toSearch, pos+1)){
		indices.push(pos);
	}
	return indices;
}	

function proxyFetchText (url,callback){
	
	
	var xhr = new XMLHttpRequest ();
	xhr.open ("GET","b2gci.fcgi?proxyFetch&url="+url);
	xhr.responseType = "blob";
	xhr.onload = function (){	
		if (this.response.size){
			console.log ("proxyFetchText Reply size = "+this.response.size);
			
			var reader = new FileReader ();
			reader.onload = function () {
//				console.log ("Head of blob = "+reader.result.slice(0,100));
				callback (0,reader.result);
			};
			reader.readAsText (this.response);				

		}
		else return (new Error ("proxyFetchText no reply"));
	};	
	xhr.send ();	
}


function scrapeYoutube (q){
	
	console.log ("scrapeYoutube () val=<"+q+">");
	
	var url = "https://www.youtube.com/results?search_query="+q.replace(" ","+");
	
	console.log ("URL = "+url);
	
	$("#youtubeSearching").show ();	
	

	proxyFetchText (url,function (err,blob){
		if (err) console.log ("Scrape failed");
		else {
			
			var n;
			
			var yt = $("<div>").html (blob);
			
			var el = yt[0].getElementsByClassName ("yt-lockup-title");
			
			youtubeSearchResults = [];
			
			for (n=0;n<el.length;n++){
				console.log (n+" "+el[n].innerText);
				console.log (el[n].firstChild.getAttribute("href"));
				
				var item = [el[n].innerText,el[n].firstChild.getAttribute("href")];

// Youtube channels begin "/user"
				
				if ((item[1].indexOf("doubleclick") == -1)&&(item[1].indexOf("/user") != 0)) youtubeSearchResults.push (item);
				
			}	
			refreshSearchResults ();
			$("#youtubeSearching").hide ();
							

		}
	});		
	
}


function youtubeGo (){
	
	var q = $('#bTubeSearchValue').val();
	$('#bTubeSearchValue').val("");
	
	console.log ("youtubeGo () val=<"+q+">");
	
	var id = getVideoID (q);
	if (id) {
		console.log ("Looks like a Youtube ID - play it");
		return startYoutube (id,function () {
			scrapeYoutube (q)
		});
	}
	else scrapeYoutube (q);
}

function getVideoID (url) {

var idRegex = /[a-zA-Z0-9-_]{11}/;
	
  var r;
  if (r = idRegex.exec(url)) {
    return r;
  }
  return null;
};


function makevTunerItem (i,data){

	if (data.flag){
		var menu = '<div><span class="flex1 mylink iconEllipsisH" onclick="vTunerItemMenu('+i+')"</span></div>';
		var link = 'class="mylink" onclick="vTunerItemClick('+i+')"';
		return '<div class="darkRow"><div class="flex1" '+link+'><span class="iconPlay"></span></div>'+
					'<div class="flex10" onclick="vTunerItemClick('+i+')" class="mylink">'+data.name+"</div>"+menu+"</div>";	
	}	
	else 
		return '<div class="darkRow"><div class="flex10" onclick="vTunerItemClick('+i+')" class="mylink">'+data.name+"</div></div>";	
	
}

function vTunerInit () {

	var vTunerLinks = $('#vTunerTable');
	vTunerLinks.children().remove();
	vTunerLinks.append ('<div><img src="ajax-loader.gif"></div>');
	
	var urlTail = 'vTunerTop&' + new Date ().getTime();			// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){			
		vTunerLinks.children().remove();
		vTunerItemResults = data;

		for (var i=0;i<data.length;i++){
			vTunerLinks.append(makevTunerItem (i,data[i]));
		}
		vTunerLinks.children().eq(0).focus();
				
	});
	
}

function vTunerGoBack (){

	var loading = $('#vTunerTable');
	loading.children().remove();
	loading.append ('<div><img src="ajax-loader.gif"></div>');

	
	var urlTail = 'vTunerBack&time='+ new Date ().getTime();		// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){	
		
		var vTunerLinks = $('#vTunerTable');
		vTunerLinks.children().remove();

		for (var i=0;i<data.length;i++){
			vTunerLinks.append(makevTunerItem (i,data[i]));
		}

				
	});	
}


function vTunerItemClick (index){

	console.log ("vTunerItemClick "+ index);

	console.log ("item Flag = "+vTunerItemResults[index].flag);
	
	if (vTunerItemResults[index].flag){								// playable

		var urlTail = 'vTunerLink&index='+index+'&time='+ new Date ().getTime();		// IE
		$.getJSON('b2gci.fcgi',urlTail,function(data){});
		activateNowPlayingTab ();
		return;
	}


	var loading = $('#vTunerTable');
	loading.children().remove();
	loading.append ('<div><img src="ajax-loader.gif"></div>');

	var urlTail = 'vTunerLink&index='+index+'&time='+ new Date ().getTime();		// IE
	$.getJSON('b2gci.fcgi',urlTail,function(data){	


		vTunerItemResults = data;		

		var vTunerLinks = $('#vTunerTable');
		vTunerLinks.children().remove();

		for (var i=0;i<data.length;i++){
			vTunerLinks.append(makevTunerItem (i,data[i]));
		}

		vTunerLinks.children().eq(0).focus();


	});	
}

function refreshSettings (){

//	console.log ("refreshSettings ()");
	
	var urlTail = 'getWebInfo&time='+ new Date ().getTime();		// IE;

	$.getJSON('b2gci.fcgi',urlTail,function(data){
//		console.log (data);
		
		var b = $('#settingsBody');
		b.children().remove();
		b.append('<p>Software '+data.version+'</p>');
		b.append('<p>'+data.tracks+' tracks in '+data.albums+' albums '+data.artists+' artists</p>');
		b.append('<p>'+data.wavs+' WAV '+data.flacs+' FLAC '+data.mp3s+' MP3 '+data.aacs+' AAC</p>');
		b.append('<p>Capacity '+data.capacity+'G Used '+data.used+'Gb</p>');
		b.append('<p>USB '+data.USBTracks+' tracks in '+data.USBAlbums+' albums '+data.USBArtists+' artists</p>');
		b.append('<p>'+data.videos+' Youtubes</p>');
	});
	
/*	
	var ul = $('#guestDropdownUl');
	ul.children().remove();
	var l = playlists.length;

	ul.append('<li role="presentation"><a role="menuitem" tabindex="-1" href="#" onclick="pickGuest(0)">All Music</a></li>');	
	for (var i=1;i<=l;i++){ 
		ul.append('<li role="presentation"><a role="menuitem" tabindex="-1" href="#" onclick="pickGuest('+i+')">'+
			playlists[i-1].name+' ('+playlists[i-1].length+')</a></li>');
	}

	
	pickGuest (lastGuestPlaylist);
*/  
}

function playAlbumTrack (index){

	id = albumTracks[index].id;
	command = 'playID&'+id
	$.get('b2cgi.fcgi',command,function(data){});
	activateNowPlayingTab ();	
		
}


function artistItemFunction (index){

	console.log ("artistItemFunction ("+index+")");

	selectedSearchItem = artistAlbums[index];

	var id = artistAlbums[index].id;
	var name = artistAlbums[index].name;

	listalbumFunction (id);

	selectedSearchItem.album = name;	
	selectedSearchItem.id = id;

	setSearchItemTitle ();
	
	if (isAlbum(id)) $(".artButton").show();
	else $(".artButton").hide();
	
	$('#searchItemModal').show();

	
}

function closeSearchItemModal (){
	
	$('#searchItemModal').hide();
	
}

function searchItemDeleteButton (){
	
	if (lastGuest==1) {
		$('#guestModeModal').show();			
		return;
	}	

	$('#searchItemModal').hide();
	$('#areYouSureModal').show();		
}		

function closeAreYouSureModal (){
	
	$('#areYouSureModal').hide();
	
}

function deleteConfirmed (){
	
	console.log ("deleteConfirmed () id = "+selectedSearchItem.id);
	
	$('#areYouSureModal').hide();
		
	var urlTail = 'deleteID&id='+selectedSearchItem.id+'&time='+ new Date ().getTime();		// IE;			
	
	console.log ("tail = "+urlTail);
	
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		searchFunction (true);					// refresh		
		listalbumAndArtistInSitu (selectedAlbum);
//		listPlaylistFunction (selectedPlaylist);
		refreshPlaylistsFunction ();				
	});		
	
}


function searchItemAddButton (){

	$('#searchItemModal').hide();

	var ul = $('#addToPlaylistDropdownUl');
	ul.children().remove();
	var l = playlists.length;
		
	for (var i=0;i<l;i++){ 
		ul.append('<a class="w3-block menuItem mylink" onclick="addToPlaylist('+i+')">'+
			playlists[i].name+' ('+playlists[i].length+')</a>');
	}	
	
	
	$('#addToPlaylistModal').show();		
}

function addToPlaylist (target){

	console.log ("addToPlaylistOK () id = "+selectedSearchItem.id+" playlist = "+target);

	$('#addToPlaylistModal').hide();
		
	if (lastGuest==1) {
		$('#guestModeModal').show();			
		return;
	}	

	urlTail = 'addIdToPlaylist&id='+selectedSearchItem.id+'&playlist='+target+'&index='+playlists[target].length+'&time='+ new Date ().getTime();		// IE;
	$.getJSON('b2gci.fcgi',urlTail,function(data){
		listPlaylistFunction (selectedPlaylist);
		refreshPlaylistsFunction ();
	});	
		
}	
	
function closeAddToPlaylistModal (){
	$('#addToPlaylistModal').hide();	
}	

function searchItemRenameButton (){

	var id = selectedSearchItem.id;

	var name = '';
	if (isTrack(id)) name = selectedSearchItem.track;
	else if (isAlbum(id)) name = selectedSearchItem.album;
	else if (isArtist(id)) name = selectedSearchItem.artist;
	else if (isRadio(id)) name = selectedSearchItem.radio;
		
	$('#searchItemModal').hide ();

	openRenameWindow (id,name);
	
}

function openRenameWindow (id,name){
	
	console.log ("openRenameWindow ("+id+","+name+")");

	if (lastGuest==1) {
		$('#guestModeModal').show();			
		return;
	}

	console.log ("CD Status ="+nowPlaying.cdstatus);
	
	if (nowPlaying.cdstatus.toLowerCase().search("rip")>=0){
		
		alert ("Not while Ripping");
		return;
		
	}	
		
	renameID = id;
	renameOldName = name;

	var title;
	if (isTrack(id)) title = "Rename Track";
	else if (isAlbum(id)) title = "Rename Album";
	else if (isArtist(id)) title = "Rename Artist";	
	else if (isPlaylist(id)) title = "Rename Playlist";

	$('#myModal').show();
	$('#renameTitle').text(title);
	$('#renameValue').val(name);
	$('#renameValue').focus();
	
	$('#renameValue').off ("keydown");
	$('#renameSecondValue').off ("keydown");
	
	$('#renameValue').keydown (function(event){
		if ((event.keyCode == 13)||event.code == 10){
			renameOKFunction ();
			return false;
		}
	});
	$('#renameSecondValue').keydown (function(event){
		if ((event.keyCode == 13)||event.code == 10){
			renameOKFunction ();
			return false;
		}
	});
	
	if (isTrack(id)) $("#renameLabel1").text("Track");
	else if (isAlbum(id)) $("#renameLabel1").text("Album");	
	else if (isArtist(id)) $("#renameLabel1").text("Artist");	
	else if (isPlaylist(id)) $("#renameLabel1").text("Playlist");
	
	if (isAlbum(id)){
		$('#renameArtist').show ();
		var urlTail = 'albumDetails&id='+id+'&time='+new Date ().getTime();			// IE
		$.getJSON('b2gci.fcgi',urlTail,function(data){
			console.log ("Album details "+data.artist);
			renameOldArtist = data.artist;
			$('#renameSecondValue').val(data.artist);		
		});	
	}
	else {
	
		$('#renameArtist').hide ();
	}	
}

function renameOKFunction (){

	var urlTail;
	var newName;
	var artistChanged;
	
	console.log ("renameOKFunction ()");
	$('#myModal').hide();

	newName = $('#renameValue').val();
	console.log ("Newname = "+newName);
	
	artistChanged = (isAlbum(renameID) && (renameOldArtist != $('#renameSecondValue').val()));
	
	if (newName != renameOldName){
		
		urlTail = 'renameID&id='+renameID+'&time='+new Date ().getTime()+'&name='+	encodeURIComponent(newName);		// IE	
		$.getJSON('b2gci.fcgi',urlTail,function(data){
			if (!artistChanged){
				searchFunction (true);					// refresh		
				listalbumAndArtistInSitu (selectedAlbum);
				listPlaylistFunction (selectedPlaylist);
				refreshPlaylistsFunction ();
			}	
		});	
	}
	
	if (artistChanged){
		newName = $('#renameSecondValue').val();		

		console.log ("Artist changed = "+newName);
			
		urlTail = 'moveID&id='+renameID+'&time='+new Date ().getTime()+'&name='+	encodeURIComponent(newName);	// IE		
		$.getJSON('b2gci.fcgi',urlTail,function(data){
			searchFunction (true);					// refresh		
			listalbumAndArtistInSitu (selectedAlbum);
			listPlaylistFunction (selectedPlaylist);
		});	
	}
	

}

function closeRenameModal (){
		$('#myModal').hide();
}	

function searchItemArt (){
	
	console.log ("searchItemArt");

	$('#searchItemModal').hide();
	
	var tb = $('#albumArtResultsTable');
	tb.children().remove();
	
	var id = selectedSearchItem.id;

	var album = '';
	var name = '';
	
	if (isAlbum(id)){
		album = selectedSearchItem.album;
		var urlTail = 'albumDetails&id='+id+'&time='+new Date ().getTime();			// IE
		$.getJSON('b2gci.fcgi',urlTail,function(data){

			$('#albumArtModal').show();
			$("#albumArtBottomLine").hide();			
			$('#artSearching').show();
			
			console.log ("artist "+data.artist);
			console.log ("album = "+album);

			$("#albumArtArtist").text(data.artist);
			$("#albumArtAlbum").text(album);

			scrapeArtUrls = [];
			scrapeArtId = id;
	
			scrapeArt (data.artist+" "+album);

		
		});	
	}
	else alert ("Albums Only");
		
	
}	

function scrapeArt (q){
	
	console.log ("scrapeArt () val=<"+q+">");
	
	q = q.replace (/  /g," ");
	q = q.replace (/ /g,"+");
	
//	var url = "https://musicbrainz.org/search?query=emeli+sande&type=release&method=indexed";
//	var url = "https://musicbrainz.org/search?query=faithless+sunday+8pm&type=release&method=indexed";
	var url = "https://musicbrainz.org/search?query="+q+"&type=release&method=indexed";
//	var url = "https://www.amazon.co.uk/s/ref=nb_sb_noss_1?url=search-alias%3Dpopular&field-keywords=emeli+sande";
		
	console.log ("URL = "+url);

	
//	$("#youtubeSearching").show ();	
	
	var mbr = [];

	proxyFetchText (url,function (err,blob){
		if (err) console.log ("Scrape failed");
		else {
			
			var n;
			var yt = $("<div>").html (blob);
			var r = yt.find(".tbl tr");
			
// results are in a table - we want first two items - score and link

			for (n=0;n<r.length;n++){
				
				var release = {};
				var $row = $(r[n]);
				release.score = $row.children()[0].innerHTML;

				var $a = $row.find('a');				
				release.href = $a.eq(0).attr('href');						// first link in row
				release.name = $a.eq(0).text();								// name
/*				
				if ((release.score > 80) && release.href) {
					console.log (n+" "+release.score+" "+release.name+" "+release.href);
					mbr.push(release);
				}	
*/
				if ((mbr.length <= 5) && release.href) {
					console.log (n+" "+release.score+" "+release.name+" "+release.href);
					mbr.push(release);
				}


			}	
			console.log ("Total "+mbr.length);

			scrapeArtPartTwo (0,mbr);						

		}
	});		
	
}

function scrapeArtPartTwo (index,results){
	
	var url = "https://musicbrainz.org"+results[index].href;
	
	console.log ("scrapeArtPartTwo () "+url);
	$("#albumArtBottomLine").text("Searching");	
	
	proxyFetchText (url,function (err,blob){
		if (err) {
			$('#artSearching').hide();	
			console.log ("Scrape failed");
			bottomLine ();
		}	
		else {
			
			var yt = $("<div>").html (blob);

//			console.dir (yt);

//			console.log ("find cover-art");
//			console.dir (yt.find(".cover-art"));

//			console.log ("find cover-art a .cover-art-image");
//			console.dir (yt.find(".cover-art a .cover-art-image"));

			var image = yt.find(".cover-art a .cover-art-image").eq(0);

			console.log ("image = "+image.html());

			var href = image.attr('data-large-thumbnail') || image.attr('data-small-thumbnail');
			
			if (!href){
				
				image = yt.find(".cover-art img").eq(0);
				href = image.attr('src');
				
			}

			var tb = $('#albumArtResultsTable');
			
			
			if (href) {
				var i = scrapeArtUrls.length;
				tb.append('<div class="darkRow"><div class="mylink" onclick="setAlbumArt('+i+')"><img onload="artLoaded('+i+')" width="75px" src="'+href+'"></div><div  class="middleItem" id="artSize'+i+'"></div></div>');

//				scrapeArtUrls.push(href.replace("//",""));
				if (href.startsWith("//")) href = "http:"+href;
				scrapeArtUrls.push(href);				
				
			}
			index++;
			if ((index < 5) && (index < results.length)) {
				scrapeArtPartTwo (index,results);
			}
			else {
				$('#artSearching').hide();
				bottomLine ();				
				
			}

		}
	});		
	

}	

function setAlbumArt (index){

	$.getJSON('b2gci.fcgi',"getArtFromURL&id="+scrapeArtId+"&url="+scrapeArtUrls[index]+"&time="+new Date ().getTime(),function(data){
		$('#albumArtModal').hide();
		listalbumAndArtistFunction (scrapeArtId);
		activateAlbumTab ();
		refreshNowPlaying ();		
	});		

	
}	

function bottomLine (){
	
	$("#albumArtBottomLine").show();
	if (scrapeArtUrls.length) $("#albumArtBottomLine").text("Click on image to use as cover art for this album");
	else $("#albumArtBottomLine").text("Nothing found");	
}

function artLoaded (index){
	
	var i = $("#albumArtResultsTable img").eq(index)[0];
	var size = i.naturalWidth+" x "+i.naturalHeight;
	$("#artSize"+index).text(size);
	
}	

function closeAlbumArtModal (){
		$('#albumArtModal').hide();	
}	

function searchItemArt2 (){
	
	console.log ("searchItemArt2");

	$('#searchItemModal').hide();
	
	var tb = $('#albumArtResultsTable');
	tb.children().remove();
	
	var id = selectedSearchItem.id;

	var album = '';
	var name = '';
	
	if (isAlbum(id)){
		album = selectedSearchItem.album;
		var urlTail = 'albumDetails&id='+id+'&time='+new Date ().getTime();			// IE
		$.getJSON('b2gci.fcgi',urlTail,function(data){

			$('#albumArtModal').show();
			$("#albumArtBottomLine").hide();				
			$('#artSearching').show();
			
			console.log ("artist "+data.artist);
			console.log ("album = "+album);

			$("#albumArtArtist").text(data.artist);
			$("#albumArtAlbum").text(album);

			scrapeArtUrls = [];
			scrapeArtId = id;
	
			scrapeArt2 (data.artist+" "+album);

		
		});	
	}
	else alert ("Albums Only");
		
	
}

function scrapeArt2 (q){
	
	console.log ("scrapeArt () val=<"+q+">");
	
	q = q.replace (/  /g," ");
	q = q.replace (/ /g,"+");
	
	var url = "https://www.amazon.co.uk/s/ref=nb_sb_noss_1?url=search-alias%3Dpopular&field-keywords="+q;
		
	console.log ("URL = "+url);

	
//	$("#youtubeSearching").show ();	
	
	var mbr = [];

	proxyFetchText (url,function (err,blob){
		if (err) console.log ("Scrape failed");
		else {
			
			var n;
			var yt = $("<div>").html (blob);
//			var r = yt.find(".s-item-container img");
			var r = yt.find(".s-image-fixed-height img");

			var tb = $('#albumArtResultsTable');

//			console.log ("Amazon scrape s-item-container count "+r.length);
			console.log ("Amazon scrape s-image-fixed-height count "+r.length);
			
			for (n=0;(n<r.length)&&(scrapeArtUrls.length<5);n++){
				
				var href = r.eq(n).attr("src");
				console.log ("Image url "+href);
				
//				href = href.replace ("https","http");
				
//				var srcset = r.eq(n).attr("srcset");
//				console.log ("srcset[0] "+srcset.split(" ")[0]);
				
				var i = scrapeArtUrls.length;
				tb.append('<div class="darkRow"><div class="mylink" onclick="setAlbumArt('+i+')"><img onload="artLoaded('+i+')" width="75px" src="'+href+'"></div><div class="middleItem" id="artSize'+i+'"></div></div>');

				if (href.startsWith("//")) href = "http:"+href;
				scrapeArtUrls.push(href);	
				
			}
			$('#artSearching').hide();
			bottomLine ();				

		}
	});		
	
}


function albumItemFunction (index){

	console.log ("albumItemFunction ("+index+")");

	selectedSearchItem = albumTracks[index];

	var id = albumTracks[index].id;
	var name = albumTracks[index].name;

	selectedSearchItem.track = name;	
	selectedSearchItem.id = id;

	setSearchItemTitle ();
	
	if (isAlbum(id)) $(".artButton").show();
	else $(".artButton").hide();
	
	$('#searchItemModal').show();

	
}

function setSearchItemTitle (){
	
	var id = selectedSearchItem.id;

	var name = '';
	var label = '';
	if (isTrack(id)) {
		label = "Track";
		name = selectedSearchItem.track;
	}	
	else if (isAlbum(id)) {
		label = "Album";
		name = selectedSearchItem.album;
	}	
	else if (isArtist(id)) {
		label = "Artist";		
		name = selectedSearchItem.artist;
	}	
	else if (isRadio(id)) {
		label = "Station";		
		name = selectedSearchItem.radio;
	}	
	else if (isVideo(id)) {
		label = "Youtube";
		name = selectedSearchItem.video;
	}	
	var title = $('#searchItemTitle');
	title.children().remove();
	title.append('<div class="muted">'+label+'</div><div>'+name+'</div>');

	$('#areYouSureTitle').html(getIcon(id)+' '+name);
	$('#addToPlaylistTitle').html(getIcon(id)+' '+name);
}		

function searchItemFunction (index){

	console.log ("searchItemFunction ("+index+")");
	
	selectedSearchItem = matches[index];

	setSearchItemTitle ();
	
	if (isAlbum(id)) $(".artButton").show();
	else $(".artButton").hide();
	
	$('#searchItemModal').show();	
	
}


function allArtistsItemMenuClick (index){
	
	console.log ("allArtistsItemMenuClick ("+index+")");

	selectedSearchItem = allArtists[index];
	var id = selectedSearchItem.id;

	var name = selectedSearchItem.artist;
	selectedSearchItem.artist = name;	
	selectedSearchItem.id = id;

	setSearchItemTitle ();	
		
	$('#areYouSureTitle').html(getIcon(id)+' '+name);
	$('#addToPlaylistTitle').html(getIcon(id)+' '+name);
	
	if (isAlbum(id)) $(".artButton").show();
	else $(".artButton").hide();
	
	$('#searchItemModal').show();
	
}	

function playPlaylistItemFunction (index){
	
	console.log ("playPlaylistItemFunction () id="+playlist[index].id);

	var pid = selectedPlaylist+4000000;
	var command = 'startPlaylist&playlist='+pid+'&id='+playlist[index].id+'&time='+ new Date ().getTime();		// IE;
	$.get('b2cgi.fcgi',command,function(data){});

	activateNowPlayingTab ();
		
}

function getLabel (id){

	if (isTrack(id)) return "Track";
	else if (isAlbum(id)) return "Album";
	else if (isArtist(id)) return "Artist";		
	else if (isRadio(id)) return "Station";		
	else if (isVideo(id)) return "Youtube";
	else return "UknownID";
}	


function playlistItemFunction (index){

	console.log ("playlistItemFunction ("+index+")");

	selectedPlaylistItem = index;
	
	var name = playlist[index].name;
	var id = playlist[index].id;
	
	var title = $('#playlistItemTitle');
	title.children().remove();
	title.append('<div class="muted">'+getLabel(id)+'</div><div>'+name+'</div>');
	
	$('#playlistItemModal').show();	
}
	
function closePlaylistItemModal() {

	$('#playlistItemModal').hide();		
		
}

function playlistItemDeleteButton (){
	
	playlistIndex = selectedPlaylistItem;
	console.log ("Removing playlist "+selectedPlaylist+" item "+playlistIndex);
	command = 'deletePlaylistIndex&playlist='+selectedPlaylist+'&index='+playlistIndex+'&' + new Date ().getTime();
	$.get('b2cgi.fcgi',command,function(data){
		listPlaylistFunction (selectedPlaylist);
		refreshPlaylistsFunction ();				
	});
	$('#playlistItemModal').hide ();		
}

function playlistItemStartButton (){
	
	playlistMove (selectedPlaylistItem,0);
	selectedPlaylistItem = 0;
	
}	
	
function playlistItemEndButton (){
	
	playlistMove (selectedPlaylistItem,playlist.length);
	selectedPlaylistItem = playlist.length-1;
	
}

function playlistItemUpButton (){
	
	if (selectedPlaylistItem > 0){
		playlistMove (selectedPlaylistItem,selectedPlaylistItem-1);
		selectedPlaylistItem--;
	}	
	
}

function playlistItemDownButton (){
	
	if (selectedPlaylistItem < playlist.length){
		playlistMove (selectedPlaylistItem,selectedPlaylistItem+1);
		selectedPlaylistItem++;
	}	

}

function playlistMove (from,to){
	
	var id;
		
	if (to == from) return;
	id = playlist[from].id;
	console.log ("playlistMove "+selectedPlaylist+" from "+from+" to "+to);

	command = 'deletePlaylistIndex&playlist='+selectedPlaylist+'&index='+from+'&time='+new Date ().getTime();			// IE
	$.get('b2cgi.fcgi',command,function(data){
//		if (from < to) to--;
			
		console.log ("Now adding id "+id+" back to index "+to);

		urlTail = 'addIdToPlaylist&id='+id+'&playlist='+selectedPlaylist+'&index='+to+'&time='+new Date ().getTime();			// IE;
		$.getJSON('b2gci.fcgi',urlTail,function(data){
			listPlaylistFunction (selectedPlaylist);
			refreshPlaylistsFunction ();
		});
	});
			
}

function playlistItemClick (i){
//	i = ev.target.parentElement.rowIndex;	
	id = playlist[i].id;
	console.log ("playlistItemClick "	+ id);
	if (isAlbum(id)) {
		listalbumAndArtistFunction (id);
		activateAlbumTab ();
	}	
	else if (isTrack (id)) {
		listTrackFunction (id);	
		activateAlbumTab ();
	}	
	else if (isArtist (id)) {
		listArtistAndFirstAlbum (id,true);
		activateArtistTab ();
	}	
}
